const C = "wn-v211";
const FILES = ["./", "index.html", "boot.js", "config.js", "manifest.webmanifest", "icon.svg", "css-base.css", "css-components.css", "css-screens.css", "css-login.css", "css-trending.css", "css-media.css", "css-utilities.css", "view-header.html", "view-tabs.html", "view-login.html", "view-pick.html", "view-discover.html", "view-chat.html", "view-schedule.html", "view-stats.html", "view-lists.html", "view-profile.html", "view-settings.html", "view-settings-app.html", "view-settings-anilist.html", "view-settings-lists.html", "view-settings-sync.html", "view-settings-account.html", "view-settings-about.html", "view-sheet-filter.html", "view-sheet-customise.html", "view-overlays.html", "js-core.js", "js-tabs.js", "js-discover.js", "js-auth.js", "js-pick-extras.js", "js-schedule-stats.js", "js-chat.js", "js-sync.js", "js-lists.js", "js-profile.js", "js-theme.js", "js-media.js", "js-editor.js", "js-trending.js", "js-settings.js", "js-boot.js"];
self.addEventListener("install", e => { e.waitUntil(caches.open(C).then(c => Promise.all(FILES.map(f => c.add(f).catch(() => {}))))); self.skipWaiting(); });
self.addEventListener("activate", e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k)))).then(() => clients.claim())));
self.addEventListener("fetch", e => {
  if(e.request.method !== "GET" || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(r => { const cp = r.clone(); caches.open(C).then(c => c.put(e.request, cp)); return r; })
    .catch(() => caches.match(e.request).then(r => r || caches.match("index.html"))));
});
