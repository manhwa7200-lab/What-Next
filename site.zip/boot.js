/* boot.js: loads the screen files, then the script files in order, then the app starts. */
(function(){
  const VIEWS = [["screens", "views/shell/header.html"], ["screens", "views/shell/tabs.html"], ["screens", "views/screens/login.html"], ["screens", "views/screens/pick.html"], ["screens", "views/screens/discover.html"], ["screens", "views/screens/chat.html"], ["screens", "views/screens/schedule.html"], ["screens", "views/screens/stats.html"], ["screens", "views/screens/lists.html"], ["screens", "views/screens/profile.html"], ["screens", "views/settings/menu.html"], ["screens", "views/settings/app.html"], ["screens", "views/settings/anilist.html"], ["screens", "views/settings/lists.html"], ["screens", "views/settings/sync.html"], ["screens", "views/settings/account.html"], ["screens", "views/settings/about.html"], ["overlays", "views/sheets/filter.html"], ["overlays", "views/sheets/customise.html"], ["overlays", "views/sheets/overlays.html"]];
  const SCRIPTS = ["js/core/core.js", "js/core/tabs.js", "js/features/discover.js", "js/core/auth.js", "js/features/pick-extras.js", "js/features/schedule-stats.js", "js/features/chat.js", "js/features/sync.js", "js/features/lists.js", "js/features/profile.js", "js/core/theme.js", "js/features/media.js", "js/features/editor.js", "js/features/trending.js", "js/features/settings.js", "js/core/start.js"];
  const fail = msg => { document.body.innerHTML = '<p style="padding:24px;font:16px sans-serif">Couldn\'t load the app (' + msg + '). Check your connection and reload.</p>'; };
  Promise.all(VIEWS.map(v => fetch(v[1], { cache: "no-cache" }).then(r => { if(!r.ok) throw new Error(v[1] + " " + r.status); return r.text(); })))
    .then(async texts => {
      const html = { screens: "", overlays: "" };
      VIEWS.forEach((v, i) => { html[v[0]] += texts[i] + "\n"; });
      document.getElementById("screens").innerHTML = html.screens;
      document.getElementById("overlays").innerHTML = html.overlays;
      for(const f of SCRIPTS){
        await new Promise((ok, bad) => { const s = document.createElement("script"); s.src = f; s.onload = ok; s.onerror = () => bad(new Error("missing " + f)); document.body.append(s); });
      }
    })
    .catch(e => fail(e.message));
})();
