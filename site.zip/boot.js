/* boot.js: loads the screen files, then the script files in order, then the app starts. */
(function(){
  const VIEWS = [["screens", "view-header.html"], ["screens", "view-tabs.html"], ["screens", "view-login.html"], ["screens", "view-pick.html"], ["screens", "view-discover.html"], ["screens", "view-chat.html"], ["screens", "view-schedule.html"], ["screens", "view-stats.html"], ["screens", "view-lists.html"], ["screens", "view-profile.html"], ["screens", "view-settings.html"], ["screens", "view-settings-app.html"], ["screens", "view-settings-anilist.html"], ["screens", "view-settings-lists.html"], ["screens", "view-settings-sync.html"], ["screens", "view-settings-account.html"], ["screens", "view-settings-about.html"], ["overlays", "view-sheet-filter.html"], ["overlays", "view-sheet-customise.html"], ["overlays", "view-overlays.html"]];
  const SCRIPTS = ["js-core.js", "js-tabs.js", "js-discover.js", "js-auth.js", "js-pick-extras.js", "js-schedule-stats.js", "js-chat.js", "js-sync.js", "js-lists.js", "js-profile.js", "js-theme.js", "js-media.js", "js-editor.js", "js-trending.js", "js-settings.js", "js-boot.js"];
  const fail = msg => { document.body.innerHTML = '<p style="padding:24px;font:16px sans-serif">Couldn\'t load the app (' + msg + '). Check your connection and reload.</p>'; };
  Promise.all(VIEWS.map(v => fetch(v[1], { cache: "no-cache" }).then(r => { if(!r.ok) throw new Error(v[1] + " " + r.status); return r.text(); })))
    .then(async texts => {
      const html = { screens: "", overlays: "" };
      VIEWS.forEach((v, i) => { html[v[0]] += texts[i] + "\n"; });
      document.getElementById("screens").innerHTML = html.screens;
      document.getElementById("overlays").innerHTML = html.overlays;
      for(const f of SCRIPTS){
        await new Promise((ok, bad) => { const s = document.createElement("script"); s.src = f; s.onload = ok; s.onerror = () => bad(new Error("missing " + f)); document.body.append(s); });
      }
    })
    .catch(e => fail(e.message));
})();
